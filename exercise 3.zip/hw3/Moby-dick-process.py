import nltk
import matplotlib.pyplot as plt
from nltk.corpus import stopwords
from nltk import FreqDist
from nltk.tokenize import word_tokenize
from nltk.tag import pos_tag
from nltk.stem import WordNetLemmatizer
from collections import Counter

# 下载必要的NLTK数据
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('averaged_perceptron_tagger')
nltk.download('wordnet')

def tokenize_text(file_path):
    with open('The Project Gutenberg eBook of Moby Dick; Or, The Whale.txt', 'r', encoding='utf-8') as file:
        text = file.read()
    tokens = word_tokenize(text)
    return tokens

def remove_stopwords(tokens):
    stop_words = set(stopwords.words('english'))
    filtered_tokens = [token for token in tokens if token.lower() not in stop_words]
    return filtered_tokens

def pos_tagging(tokens):
    pos_tags = pos_tag(tokens)
    return [{'token': token, 'tag': tag} for token, tag in pos_tags]

def get_top_pos_tags(pos_tags, n=5):
    tag_counts = Counter(tag_info['tag'] for tag_info in pos_tags)
    top_tags = tag_counts.most_common(n)
    return top_tags

def lemmatize_tokens(tokens, pos_tags, n=20):
    lemmatizer = WordNetLemmatizer()
    lemmatized_tokens = []
    for tag_info in pos_tags:
        token = tag_info['token']
        tag = tag_info['tag']
        # Map Penn Treebank POS tags to WordNet POS tags for lemmatization
        if tag.startswith('N'):
            tag = 'n'
        elif tag.startswith('V'):
            tag = 'v'
        elif tag.startswith('R'):
            tag = 'r'
        elif tag.startswith('J'):
            tag = 'a'
        else:
            tag = 'n'  # Default to noun
        lemmatized_token = lemmatizer.lemmatize(token, tag)
        lemmatized_tokens.append(lemmatized_token)
    return lemmatized_tokens[:n]

def plot_pos_frequency(pos_tags):
    labels, frequencies = zip(*Counter(tag_info['tag'] for tag_info in pos_tags).items())
    plt.figure(figsize=(12, 6))
    plt.bar(labels, frequencies, color='skyblue')
    plt.xlabel('POS Tags')
    plt.ylabel('Frequency')
    plt.title('POS Tags Frequency Distribution')
    plt.xticks(rotation=90)
    plt.show()

# 主函数
def main():
    file_path = 'mobydick.txt'  # 替换成实际的文件路径

    # 步骤1：Tokenization
    tokens = tokenize_text(file_path)

    # 步骤2：Stop-words filtering
    filtered_tokens = remove_stopwords(tokens)

    # 步骤3：Parts-of-Speech (POS) tagging
    pos_tags = pos_tagging(filtered_tokens)

    # 步骤4：POS frequency
    top_pos_tags = get_top_pos_tags(pos_tags)
    print("Top 5 POS Tags and their frequencies:")
    for tag, frequency in top_pos_tags:
        print(f"{tag}: {frequency}")

    # 步骤5：Lemmatization
    lemmatized_tokens = lemmatize_tokens(filtered_tokens, pos_tags)
    print("\nTop 20 Lemmatized Tokens:")
    print(lemmatized_tokens)

    # 步骤6：Plotting frequency distribution
    plot_pos_frequency(pos_tags)

if __name__ == "__main__":
    main()
